// Función para realizar cálculos matemáticos
function calculate(firstValue, operator, secondValue) {
  firstValue = parseFloat(firstValue);
  secondValue = parseFloat(secondValue);

  if (operator === '+') {
    return firstValue + secondValue;
  } else if (operator === '-') {
    return firstValue - secondValue;
  } else if (operator === '*') {
    return firstValue * secondValue;
  } else if (operator === '/') {
    return firstValue / secondValue;
  } else if (operator === '%') {
    return (firstValue * secondValue) / 100;
  } else if (operator === 'x²') {
    return Math.pow(firstValue, 2);
  } else if (operator === '√') {
    return Math.sqrt(firstValue);
  }
}

// Obtener la referencia al elemento de pantalla de la calculadora
const display = document.querySelector('.calculator__display');

// Obtener todas las teclas de la calculadora
const keys = document.querySelectorAll('.calculator__keys button');

// Variables para realizar el cálculo
let firstValue = '';
let operator = '';
let awaitingNextValue = false;

// Función para actualizar el contenido de la pantalla
function updateDisplay(content) {
  display.textContent = content;
}

// Agregar el evento de clic a cada tecla
keys.forEach(key => {
  key.addEventListener('click', () => {
    const keyContent = key.textContent;
    const action = key.dataset.action;

    if (!action) {
      // Si no es una acción especial, actualizar el número en la pantalla
      if (operator && awaitingNextValue) {
        updateDisplay(keyContent);
        awaitingNextValue = false;
      } else {
        const displayedNum = display.textContent;
        updateDisplay(displayedNum === '0' ? keyContent : displayedNum + keyContent);
      }
    } else if (
      action === 'sumar' ||
      action === 'resta' ||
      action === 'multiplicar' ||
      action === 'dividir' ||
      action === 'porcentaje' ||
      action === 'cuadrado' ||
      action === 'raiz'
    ) {
      // Si es una operación matemática (+, -, *, /), almacenarla y actualizar el operador
      operator = action === 'sumar' ? '+' :
        action === 'resta' ? '-' :
          action === 'multiplicar' ? '*' :
            action === 'dividir' ? '/' :
              action === 'porcentaje' ? '%' :
                action === 'cuadrado' ? 'x²' : '√';
      if (operator === 'cuadrado' || operator === '√') {
        const currentValue = parseFloat(display.textContent);
        const result = calculate(currentValue, operator);
        updateDisplay(result);
        firstValue = result;
        operator = '';
        awaitingNextValue = true;
      } else {
        firstValue = display.textContent;
        awaitingNextValue = true;
      }
    } else if (action === 'decimal') {
      // Si es el botón decimal, asegurarse de que solo se pueda agregar un punto decimal
      if (!display.textContent.includes('.')) {
        updateDisplay(display.textContent + '.');
      }
    } else if (action === 'clear') {
      // Si es el botón de borrar (AC), limpiar la pantalla y los datos almacenados
      updateDisplay('0');
      firstValue = '';
      operator = '';
      awaitingNextValue = false;
    } else if (action === 'calculate') {
      // Si es el botón de calcular (=), realizar la operación matemática
      const secondValue = display.textContent;
      if (firstValue && operator && secondValue) {
        const result = calculate(firstValue, operator, secondValue);
        updateDisplay(result);
        firstValue = result;
        operator = '';
        awaitingNextValue = true;
      }
    }
  });
});


